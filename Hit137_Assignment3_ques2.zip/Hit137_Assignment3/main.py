# importing the required modules
import pygame
import sys
from pygame import mixer
import random
import math
import os

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base_path, relative_path)

import time

# initialising the pygame
pygame.init()

# variables_used
line_image = pygame.image.load(resource_path('black_simple.png'))
height = 675
width = 500
icon = pygame.image.load(resource_path("001-tank16.png"))
background_image_1 = pygame.image.load(resource_path('Screenshot 2021-03-24 203113.png'))
background_image_2 = pygame.image.load(resource_path('Screenshot 2021-03-24 203113.png'))
tank_image = pygame.image.load(resource_path('001-tank64.png'))
y1 = 0
y2 = -675
track_speed = 1

bullet_image = pygame.image.load(resource_path('001-bullet.png'))



enemy_1_image = pygame.image.load(resource_path('002-tank-1.png'))

enemy_2_image = pygame.image.load(resource_path('002-jet-1.png'))


mine_image = pygame.image.load(resource_path('icons8-fluent-50.png'))



boss_image = pygame.image.load(resource_path('009-tank.png'))



life_image = pygame.image.load(resource_path('001-heart.png'))

# designing the screen
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("TANK SHOOTING")
pygame.display.set_icon(icon)

# background music
mixer.music.load(resource_path('videoplayback (3).mp3'))
pygame.mixer.music.set_volume(0.1)
mixer.music.play(-1)

explosions = [pygame.image.load(resource_path('exp1.png')), pygame.image.load(resource_path('exp2.png')), pygame.image.load(resource_path('exp3.png')),
              pygame.image.load(resource_path('exp4.png')), pygame.image.load(resource_path('exp5.png'))]
clock = pygame.time.Clock()

run = True

class tank():
    def __init__(self):
        self.x = width / 2 - 25
        self.y = height - 100
        self.xc = 0
        
    def show_tank(self):
        screen.blit(tank_image, (self.x, self.y))

class bullet():
    def __init__(self):
        self.y = height -100
        self.x = tanks.x 
        self.yc = 0
        self.xc = 0
    
    def show_bullet(self):
        if self.y < tanks.y:
            screen.blit(bullet_image, (self.x, self.y))


    def ready_bullet(self):
       self.yc = 0
       self.y = tanks.y
       self.x = tanks.x + 20


    def fire_bullet(self):
       self.x = tanks.x + 20
       self.yc = -20

class enemy1():
    def __init__(self):
        self.x = random.randint(40, 410)
        self.y = -100
        self.xc = 0
        self.yc = 3
        
    def show_enemy(self):
        screen.blit(enemy_1_image, (self.x, self.y))
        
class enemy2():
    def __init__(self):
        self.x = random.randint(40, 410)
        self.y = -100
        self.xc = 0
        self.yc = 10
        
    def show_enemy(self):
        screen.blit(enemy_2_image, (self.x, self.y))
        
class mines():
    def __init__(self):
        self.x = random.randint(150, 300)
        self.y = -200
        self.xc = 0
        self.yc = track_speed
        
    def show_mine(self):
        screen.blit(mine_image, (self.x, self.y))
   


class enemy3():
    def __init__(self):
        self.x = random.randint(120, 300)
        self.y = -3000
        self.xc = 5
        self.yc =10
       
    
    def show_enemy(self):
        screen.blit(boss_image, (self.x, self.y))


class collision:
    def __init__(self):
        pass
    
    def is_collision(self,a,b,x,y,d):
        dist_btw_bullet_enemy = math.sqrt(math.pow(a - x, 2) + math.pow(b - y, 2))
        if dist_btw_bullet_enemy <= d:
            return True


    def explosion_animation(self,x, y):
        for explosion in explosions:
            screen.blit(explosion, (x, y))
            pygame.display.update()
            if explosion == explosions[4]:
                break

class score():
    def __init__(self):
        self.score = 0
        self.highscore = []
        self.life = 100
        self.life_x = random.randint(120, 300)
        self.life_y = -1000
        self.xc = 4
        self.yc = 3
        self.x=10
        self.y=10

    def score_display(self,x,y):
        font = pygame.font.Font(resource_path('FreeSansBold.ttf'), 32)

        score_display = font.render('SCORE:' + str(scores.score), True, (230, 230, 230))
        screen.blit(score_display, (x, y))



    def life_display(self,x,y):
        screen.blit(life_image, (self.life_x,self.life_y))
        font = pygame.font.Font(resource_path('FreeSansBold.ttf'), 25)

        life_display = font.render('LIFE:' + str(scores.life), True, (250, 230, 230))
        screen.blit(life_display, (x, y))
       # level_display=font.render('LEVEL_'+ str((scores.score//10)+1), True, (255, 0, 0))
        #screen.blit(level_display, (200,300))
        
        


    def game_over(self,x,y,x1,y1):
        screen.blit(background_image_1, (0, 0))
        font = pygame.font.Font(resource_path('FreeSansBold.ttf'), 60)   
        game_over_display = font.render('GAME  OVER', True, (255, 0, 0))
        screen.blit(game_over_display, (x, y))

        font_replay = pygame.font.Font(resource_path('FreeSansBold.ttf'), 25)
        replay = font_replay.render('press enter to replay.', True, (230, 230, 230))
        screen.blit(replay, (x1,y1))
        scores.score_display(60,320)
        
        
    def winner(self,x,y,x1,y1):
        screen.blit(background_image_1, (0, 0))
        font = pygame.font.Font(resource_path('FreeSansBold.ttf'), 60)   
        gamedisplay = font.render('You Win', True, (255, 0, 0))
        screen.blit(gamedisplay, (x, y))

        font_replay = pygame.font.Font(resource_path('FreeSansBold.ttf'), 25)
        replay = font_replay.render('press enter to replay.', True, (230, 230, 230))
        screen.blit(replay, (x1,y1))
        scores.score_display(60,320)
       

class level():
    def __init__(self):
        pass
        
    
    def execute(self):
        if scores.score<=10:
            
            return enem1
        elif scores.score<=20:
            return enem2
        else:
            return enem3


tanks=tank()
bull=bullet()
scores=score()
enem1=enemy1()
enem2=enemy2()
enem3=enemy3()
mine=mines()
colli=collision()
levels=level()
    


def main():
    run = True
    global y1
    global y2
    global track_speed
    y1 = 0
    y2 = -675
    track_speed = 1
    tanks.x = width / 2 - 25
    tanks.y = height - 100
    tanks.xc = 0
    bull.y = height - 100
    bull.x = tanks.x + 20
    bull.yc = 0
    # ##### enemy #######
    enem1.x = random.randint(40, 410)
    enem1.y = -100
    enem1.xc = 0
    enem1.yc = 3
    enem2.x = random.randint(40, 410)
    enem2.y = -200
    enem2.xc = 0
    enem2.yc = 10
    mine.x = random.randint(150, 300)
    mine.y = -200
    mine.yc = track_speed
    
    enem3.x = random.randint(120, 300)
    enem3.y = -200
    enem3.xc = 5
    enem3.yc =10
    
    # score
    scores.score = 0
    scores.life = 100
    scores.life_x = random.randint(120, 300)
    scores.life_y = -1000
    scores.xc = 4
    scores.yc = 6
    
    
    while run:
        gun=levels.execute()
        pygame.time.delay(20)
        screen.blit(background_image_1, (0, y1))
        screen.blit(background_image_2, (0, y2))
        for event in pygame.event.get():
            # exit event
            if event.type == pygame.QUIT:
                sys.exit()

            # moving tank and firing the bullets
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                    tanks.xc = 10

                if event.key == pygame.K_LEFT:
                    tanks.xc = -10
                if event.key == pygame.K_UP:
                    track_speed = 4
                    
                    gun.yc                    
                    scores.yc = 6
                    acceleration_sound = mixer.Sound(
                        resource_path('Car-Driving-B1-www.fesliyanstudios.com-[AudioTrimmer.com] (1).mp3'))
                    acceleration_sound.play(-1)

                if event.key == pygame.K_SPACE:
                    if bull.y == tanks.y:
                        bullet_sound = mixer.Sound(resource_path('GunShotSnglShotIn PE1097906.mp3'))
                        bullet_sound.play()
                        bull.fire_bullet()
                if event.key == pygame.K_RETURN:
                    run = False

            if event.type == pygame.KEYUP:
                if event.key == pygame.K_RIGHT or event.key == pygame.K_LEFT:
                    tanks.xc = 0
                if event.key == pygame.K_UP:
                    track_speed = 1
                    gun.yc
                    acceleration_sound.stop()
            # #### collision ######
            collision1 = colli.is_collision(gun.x+40, gun.y+40, bull.x, bull.y,100)
            if collision1 == True:
               if gun==enem3:
                   ex_sound = mixer.Sound(resource_path('mixkit-bomb-explosion-in-battle-2800.wav'))
                   ex_sound.play()
                   colli.explosion_animation(gun.x, gun.y)
                   gun.x = random.randint(40, 410)
                   gun.y = -200
                   bull.ready_bullet()
                   scores.score += 1 
                   
               else:
                    ex_sound = mixer.Sound(resource_path('mixkit-bomb-explosion-in-battle-2800.wav'))
                    ex_sound.play()
                    colli.explosion_animation(gun.x, gun.y)
                    gun.x = random.randint(40, 410)
                    gun.y = -200
                    bull.ready_bullet()
                    scores.score += 1      
                
            collision2 = colli.is_collision(enem3.x+25, enem3.y+25, x=tanks.x, y=tanks.y,d=50)
            if collision2 == True:
                ex_sound = mixer.Sound(resource_path('mixkit-bomb-explosion-in-battle-2800.wav'))
                ex_sound.play()
                colli.explosion_animation(mine.x, mine.y)
                bull.ready_bullet()
                mine.x = random.randint(40, 410)
                mine.y = random.randint(300, 450)
                colli.explosion_animation(mine.x, mine.y)
                scores.life -= 20
            collision3 = colli.is_collision(mine.x+25, mine.y+25, x=tanks.x, y=tanks.y,d=50)
            if collision3 == True:
                ex_sound = mixer.Sound(resource_path('mixkit-bomb-explosion-in-battle-2800.wav'))
                ex_sound.play()
                colli.explosion_animation(mine.x, mine.y)
                bull.ready_bullet()
                mine_2x = random.randint(40, 410)
                mine_2y = random.randint(0, 100)
                colli.explosion_animation(mine.x, mine.y)
                scores.life -= 20
            collision4 = colli.is_collision(scores.life_x, scores.life_y, x=tanks.x, y=tanks.y,d=50)
            if collision4 == True:
                ex_sound = mixer.Sound(resource_path('preview.mp3'))
                ex_sound.play()
                scores.life_x = random.randint(40, 410)
                scores.life_y = random.randint(-4000, -1000)
                scores.life += 5

        y1 += track_speed
        y2 += track_speed

        # making the bullet to move seperately.

        if y1 >= 675:
            y1 = -675
        if y2 >= 675:
            y2 = -675
        bull.y += bull.yc
        if bull.y < 0:
            bull.ready_bullet()

        if tanks.x <= 40:
            tanks.x = 40
        if tanks.x >= 410:
            tanks.x = 410
        tanks.x += tanks.xc

        bull.show_bullet()
        if bull.y == tanks.y:
            bull.x = tanks.x + 20

        # ##### respawning enemy1 #######
        if gun==enem3:
             if gun.y >= 675:
                gun.x = random.randint(120, 300)
                gun.y = -200
                haha_sound = mixer.Sound(resource_path('videoplayback (7).mp3'))
                haha_sound.play()
                
                scores.life-=30
            # moving the boss on x axis
             if gun.x >= 300:
                gun.x = 300
                gun.xc = -4

             if gun.x <= 120:
                gun.x = 120
                gun.xc = 4
           

             gun.y += gun.yc
             gun.x += gun.xc   
              
        else:
            if gun.y >= 675:
               gun.x = random.randint(40, 410)
               gun.y = 0
               scores.life-=10

            gun.y += gun.yc

       

        if scores.life_y >= 675:
            scores.life_x = random.randint(120, 300)
            scores.life_y = -4000
            # moving the boss on x axis
        if scores.life_x >= 300:
            scores.life_x = 300
            scores.life_xc = -8

        if scores.life_x <= 120:
            scores.life_x = 120
            scores.life_xc = 8

        if mine.y >= 675:
            mine.y = random.randint(300, 450)
            mine.x = random.randint(40, 380)

        mine.y += track_speed

        if mine.y >= 675:
            mine.y = random.randint(0, 100)
            mine.x = random.randint(40, 380)

        mine.y += track_speed

        mine.show_mine()
        tanks.show_tank()
        gun.show_enemy()
        scores.score_display(10, 10)
        scores.highscore.append(score)
        font = pygame.font.Font(resource_path('FreeSansBold.ttf'), 30)
        level_display=font.render('LEVEL_'+ str((scores.score//10)+1), True, (255, 0, 0))
        screen.blit(level_display, (200,300))
        
        if gun.y >= 530 and gun.y <= 600 and gun==enem3:
            scores.life -= 2
        if gun.y >= 530 and gun.y <= 600:
            scores.life -= 1
        

        scores.life_x += scores.xc
        scores.life_y += scores.yc

        scores.life_display(10,50)
        if scores .life <= 0:
            scores.game_over(60, 250, 10, 10)

        
        if scores.score==30:
            scores.winner(60,250,10,10)
            
        
        pygame.display.update()   
        
    main()


main()
